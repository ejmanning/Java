import javax.swing.JFrame;


public class ButtonViewer1 {
	public static void main(String [] args) {
		JFrame frame1 = new ButtonFrame1();
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame1.setVisible(true);
		frame1.setTitle("Click the Buttons");
		
	}
}	
