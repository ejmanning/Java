
public class Magazine implements Turner {

	@Override
	public String turn() {
		return "Going to the next page";
	}

}
