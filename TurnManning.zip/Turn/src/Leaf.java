
public class Leaf implements Turner{

	@Override
	public String turn() {
		return "Changing colors";
	}

}
