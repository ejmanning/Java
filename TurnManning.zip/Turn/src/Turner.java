
public interface Turner {
	public String turn();
}
