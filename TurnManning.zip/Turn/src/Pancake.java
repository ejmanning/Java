
public class Pancake implements Turner {

	@Override
	public String turn() {
		return "Flipping!";
	}
	
}
