
public class TurnerTester {

	public static void main(String[] args) {
		Leaf oak = new Leaf();
		Magazine comic = new Magazine();
		Pancake jack = new Pancake();
		
		System.out.println(oak.turn());
		System.out.println(comic.turn());
		System.out.println(jack.turn());

	}

}
